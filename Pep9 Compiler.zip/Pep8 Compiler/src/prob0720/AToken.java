package prob0720;

/**
 * The abstract token class.
 *
 * <p>
 * File: <code>AToken.java</code>
 *
 
 */
abstract public class AToken {

    public abstract String getDescription();
}
