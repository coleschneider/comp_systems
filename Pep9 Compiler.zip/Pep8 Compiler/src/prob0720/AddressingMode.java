package prob0720;

/**
 *
 * @Frank Garcia
 */
public enum AddressingMode {
    M_IMMEDIATE, M_DIRECT, M_INDIRECT, M_STACKRELATIVE, M_STACKRELATIVEDEFERRED, 
    M_INDEXED, M_STACKINDEXED, M_STACKINDEXEDDEFERRED, M_E
}
