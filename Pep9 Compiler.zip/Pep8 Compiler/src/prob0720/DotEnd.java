package prob0720;

/**
 *
 
 */
public class DotEnd extends ACode {
    //Do nothing
    
    @Override
    public String generateListing() {
        return String.format(".END\n");
    }
    
    @Override
    public String generateCode() {
        return "For Later";
    }
}
