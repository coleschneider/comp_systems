package prob0720;

/**
 *
 
 */
public class EmptyInstr extends ACode {
    // Do nothing
    
    @Override 
    public String generateListing() {
        return "\n";
    }
    
    @Override
    public String generateCode() {
        return "";
    }
}
