package prob0720;

/**
 *
 * @Frank Garcia
 */
public enum Mnemon {
    M_STOP, M_ASLA, M_ASRA, M_BR, M_BRLT, M_BREQ, M_BRLE, M_CPA, M_DECI, M_DECO,
    M_ADDA, M_SUBA, M_STA, M_LDA, M_BLOCK, M_END, M_DECIMAL, M_HEXADECIMAL, 
}
