package prob0720;

/**
 *
 * @Frank Garcia
 */
public enum ParseState {
    PS_START, PS_DOT1, PS_DOT2, PS_INSTR, PS_INT, PS_ADDR, PS_STOP
}

