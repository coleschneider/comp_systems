package prob0720;

/**
 *
 
 */
public class UnaryInstr extends ACode {
    
    private final Mnemon mnemonic;
    
    public UnaryInstr(Mnemon mn) {
        mnemonic = mn;
    }
    
    @Override
    public String generateListing() {
        return String.format("%s\n", Maps.mnemonStringTable.get(mnemonic));
    }
    
    @Override
    public String generateCode() {
        return "For Later";
    }
}
