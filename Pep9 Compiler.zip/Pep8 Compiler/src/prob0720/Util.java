package prob0720;

/**
 * Utility functions to test for digit characters and alphabetic characters.
 *
 * <p>
 * File: <code>Util.java</code>
 *
 
 */
public class Util {

    public static boolean isDigit(char ch) {
        return ('0' <= ch) && (ch <= '9');
    }

    public static boolean isAlpha(char ch) {
        return (('a' <= ch) && (ch <= 'z') || ('A' <= ch) && (ch <= 'Z'));
    }
    
    public static boolean isHex(char ch) {
        return (('a' <= ch) && (ch <= 'f') || ('A' <= ch) && (ch <= 'F'));
    }
}
